const express = require('express');
const db = require('../config/database');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// Apply authentication to all routes
router.use(authenticateToken);
router.use(requireRole('teacher'));

// Get teacher's personal timetable
router.get('/timetable', (req, res) => {
    const query = `
        SELECT 
            sc.*,
            c.name as course_name,
            c.code as course_code,
            c.type as course_type,
            r.name as room_name,
            r.type as room_type,
            ts.day_of_week,
            ts.slot_index,
            ts.start_time,
            ts.end_time,
            b.name as batch_name,
            b.section,
            b.semester,
            b.year
        FROM scheduled_classes sc
        JOIN courses c ON sc.course_id = c.id
        JOIN rooms r ON sc.room_id = r.id
        JOIN time_slots ts ON sc.time_slot_id = ts.id
        JOIN batches b ON sc.batch_id = b.id
        JOIN teachers t ON sc.teacher_id = t.id
        WHERE t.user_id = ?
        ORDER BY ts.day_of_week, ts.slot_index
    `;

    db.query(query, [req.user.userId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        // Group results by day and slot
        const timetable = {};
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        days.forEach(day => {
            timetable[day] = {};
            for (let slot = 1; slot <= 6; slot++) {
                timetable[day][slot] = [];
            }
        });

        results.forEach(row => {
            if (timetable[row.day_of_week] && timetable[row.day_of_week][row.slot_index]) {
                timetable[row.day_of_week][row.slot_index].push({
                    id: row.id,
                    course_name: row.course_name,
                    course_code: row.course_code,
                    course_type: row.course_type,
                    room_name: row.room_name,
                    room_type: row.room_type,
                    batch_name: row.batch_name,
                    section: row.section,
                    semester: row.semester,
                    year: row.year,
                    time: `${row.start_time.substring(0,5)} - ${row.end_time.substring(0,5)}`
                });
            }
        });

        res.json({ timetable });
    });
});

// Submit change request
router.post('/change-request', (req, res) => {
    const { scheduled_class_id, reason } = req.body;

    if (!scheduled_class_id || !reason) {
        return res.status(400).json({ error: 'Scheduled class ID and reason are required' });
    }

    // First, verify the class belongs to this teacher
    const verifyQuery = `
        SELECT sc.*, t.id as teacher_id 
        FROM scheduled_classes sc
        JOIN teachers t ON sc.teacher_id = t.id
        WHERE sc.id = ? AND t.user_id = ?
    `;

    db.query(verifyQuery, [scheduled_class_id, req.user.userId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        if (results.length === 0) {
            return res.status(403).json({ error: 'Class not found or not authorized' });
        }

        const teacher_id = results[0].teacher_id;

        // Insert change request
        const insertQuery = `
            INSERT INTO change_requests (teacher_id, scheduled_class_id, reason)
            VALUES (?, ?, ?)
        `;

        db.query(insertQuery, [teacher_id, scheduled_class_id, reason], (err, result) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Database error' });
            }

            res.status(201).json({
                message: 'Change request submitted successfully',
                request_id: result.insertId
            });
        });
    });
});

// Get teacher's change requests
router.get('/change-requests', (req, res) => {
    const query = `
        SELECT 
            cr.*,
            c.name as course_name,
            c.code as course_code,
            b.name as batch_name,
            b.section,
            ts.day_of_week,
            ts.start_time,
            ts.end_time,
            r.name as room_name
        FROM change_requests cr
        JOIN teachers t ON cr.teacher_id = t.id
        JOIN scheduled_classes sc ON cr.scheduled_class_id = sc.id
        JOIN courses c ON sc.course_id = c.id
        JOIN batches b ON sc.batch_id = b.id
        JOIN time_slots ts ON sc.time_slot_id = ts.id
        JOIN rooms r ON sc.room_id = r.id
        WHERE t.user_id = ?
        ORDER BY cr.requested_at DESC
    `;

    db.query(query, [req.user.userId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        res.json(results);
    });
});

module.exports = router;
