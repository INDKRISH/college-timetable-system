const express = require('express');
const db = require('../config/database');

const router = express.Router();

// Get branches for selection
router.get('/branches', (req, res) => {
    const query = `
        SELECT b.*, d.name as department_name 
        FROM branches b 
        JOIN departments d ON b.department_id = d.id
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
});

// Get batches for a branch
router.get('/batches/:branchId', (req, res) => {
    const { branchId } = req.params;

    const query = `
        SELECT DISTINCT semester, year 
        FROM batches 
        WHERE branch_id = ? 
        ORDER BY semester, year
    `;

    db.query(query, [branchId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
});

// Get timetable for specific branch, semester, and year
router.get('/timetable/:branchId/:semester/:year', (req, res) => {
    const { branchId, semester, year } = req.params;

    const query = `
        SELECT 
            sc.*,
            c.name as course_name,
            c.code as course_code,
            c.type as course_type,
            t.name as teacher_name,
            r.name as room_name,
            r.type as room_type,
            ts.day_of_week,
            ts.slot_index,
            ts.start_time,
            ts.end_time,
            b.name as batch_name,
            b.section,
            br.name as branch_name
        FROM scheduled_classes sc
        JOIN courses c ON sc.course_id = c.id
        JOIN teachers t ON sc.teacher_id = t.id
        JOIN rooms r ON sc.room_id = r.id
        JOIN time_slots ts ON sc.time_slot_id = ts.id
        JOIN batches b ON sc.batch_id = b.id
        JOIN branches br ON b.branch_id = br.id
        WHERE br.id = ? AND b.semester = ? AND b.year = ?
        ORDER BY ts.day_of_week, ts.slot_index, b.section
    `;

    db.query(query, [branchId, semester, year], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        // Group results by day and slot
        const timetable = {};
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        days.forEach(day => {
            timetable[day] = {};
            for (let slot = 1; slot <= 6; slot++) {
                timetable[day][slot] = [];
            }
        });

        results.forEach(row => {
            if (timetable[row.day_of_week] && timetable[row.day_of_week][row.slot_index]) {
                timetable[row.day_of_week][row.slot_index].push({
                    id: row.id,
                    course_name: row.course_name,
                    course_code: row.course_code,
                    course_type: row.course_type,
                    teacher_name: row.teacher_name,
                    room_name: row.room_name,
                    room_type: row.room_type,
                    batch_name: row.batch_name,
                    section: row.section,
                    time: `${row.start_time.substring(0,5)} - ${row.end_time.substring(0,5)}`
                });
            }
        });

        res.json({
            branch_name: results.length > 0 ? results[0].branch_name : '',
            semester: semester,
            year: year,
            timetable: timetable
        });
    });
});

module.exports = router;
