const express = require('express');
const db = require('../config/database');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// Apply authentication to all admin routes
router.use(authenticateToken);
router.use(requireRole('admin'));

// Get dashboard statistics
router.get('/dashboard', (req, res) => {
    const queries = {
        teachers: 'SELECT COUNT(*) as count FROM teachers',
        courses: 'SELECT COUNT(*) as count FROM courses',
        rooms: 'SELECT COUNT(*) as count FROM rooms',
        batches: 'SELECT COUNT(*) as count FROM batches',
        scheduled_classes: 'SELECT COUNT(*) as count FROM scheduled_classes',
        pending_requests: 'SELECT COUNT(*) as count FROM change_requests WHERE status = "pending"'
    };

    const stats = {};
    let completed = 0;
    const totalQueries = Object.keys(queries).length;

    Object.keys(queries).forEach(key => {
        db.query(queries[key], (err, results) => {
            if (err) {
                console.error(`Error fetching ${key}:`, err);
                stats[key] = 0;
            } else {
                stats[key] = results[0].count;
            }

            completed++;
            if (completed === totalQueries) {
                res.json(stats);
            }
        });
    });
});

// CRUD operations for teachers
router.get('/teachers', (req, res) => {
    const query = `
        SELECT t.*, u.username, u.email as user_email
        FROM teachers t
        LEFT JOIN users u ON t.user_id = u.id
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
});

router.post('/teachers', (req, res) => {
    const { name, email, phone, max_hours_per_day, max_hours_per_week } = req.body;

    if (!name || !email) {
        return res.status(400).json({ error: 'Name and email are required' });
    }

    const query = 'INSERT INTO teachers (name, email, phone, max_hours_per_day, max_hours_per_week) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [name, email, phone || null, max_hours_per_day || 6, max_hours_per_week || 30], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.status(201).json({ message: 'Teacher created successfully', id: result.insertId });
    });
});

router.put('/teachers/:id', (req, res) => {
    const { id } = req.params;
    const { name, email, phone, max_hours_per_day, max_hours_per_week } = req.body;

    const query = 'UPDATE teachers SET name = ?, email = ?, phone = ?, max_hours_per_day = ?, max_hours_per_week = ? WHERE id = ?';
    db.query(query, [name, email, phone, max_hours_per_day, max_hours_per_week, id], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Teacher not found' });
        }

        res.json({ message: 'Teacher updated successfully' });
    });
});

router.delete('/teachers/:id', (req, res) => {
    const { id } = req.params;

    const query = 'DELETE FROM teachers WHERE id = ?';
    db.query(query, [id], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Teacher not found' });
        }

        res.json({ message: 'Teacher deleted successfully' });
    });
});

// CRUD operations for courses
router.get('/courses', (req, res) => {
    const query = `
        SELECT c.*, b.name as branch_name
        FROM courses c
        LEFT JOIN branches b ON c.branch_id = b.id
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
});

router.post('/courses', (req, res) => {
    const { code, name, credits, type, hours_per_week, branch_id, semester } = req.body;

    if (!code || !name || !branch_id) {
        return res.status(400).json({ error: 'Code, name, and branch are required' });
    }

    const query = 'INSERT INTO courses (code, name, credits, type, hours_per_week, branch_id, semester) VALUES (?, ?, ?, ?, ?, ?, ?)';
    db.query(query, [code, name, credits || 3, type || 'Theory', hours_per_week || 3, branch_id, semester], (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ error: 'Course code already exists' });
            }
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.status(201).json({ message: 'Course created successfully', id: result.insertId });
    });
});

// Get change requests for approval
router.get('/change-requests', (req, res) => {
    const query = `
        SELECT 
            cr.*,
            t.name as teacher_name,
            c.name as course_name,
            c.code as course_code,
            b.name as batch_name,
            b.section,
            ts.day_of_week,
            ts.start_time,
            ts.end_time,
            r.name as room_name
        FROM change_requests cr
        JOIN teachers t ON cr.teacher_id = t.id
        JOIN scheduled_classes sc ON cr.scheduled_class_id = sc.id
        JOIN courses c ON sc.course_id = c.id
        JOIN batches b ON sc.batch_id = b.id
        JOIN time_slots ts ON sc.time_slot_id = ts.id
        JOIN rooms r ON sc.room_id = r.id
        ORDER BY cr.requested_at DESC
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
});

// Process change request (approve/reject)
router.put('/change-requests/:id', (req, res) => {
    const { id } = req.params;
    const { status, admin_notes } = req.body;

    if (!status || !['approved', 'rejected'].includes(status)) {
        return res.status(400).json({ error: 'Valid status (approved/rejected) is required' });
    }

    const query = 'UPDATE change_requests SET status = ?, admin_notes = ?, processed_at = NOW() WHERE id = ?';
    db.query(query, [status, admin_notes || null, id], (err, result) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Change request not found' });
        }

        res.json({ message: `Change request ${status} successfully` });
    });
});

// Get all timetable data
router.get('/timetable', (req, res) => {
    const query = `
        SELECT 
            sc.*,
            c.name as course_name,
            c.code as course_code,
            c.type as course_type,
            t.name as teacher_name,
            r.name as room_name,
            r.type as room_type,
            ts.day_of_week,
            ts.slot_index,
            ts.start_time,
            ts.end_time,
            b.name as batch_name,
            b.section,
            b.semester,
            b.year,
            br.name as branch_name
        FROM scheduled_classes sc
        JOIN courses c ON sc.course_id = c.id
        JOIN teachers t ON sc.teacher_id = t.id
        JOIN rooms r ON sc.room_id = r.id
        JOIN time_slots ts ON sc.time_slot_id = ts.id
        JOIN batches b ON sc.batch_id = b.id
        JOIN branches br ON b.branch_id = br.id
        ORDER BY br.name, b.semester, b.section, ts.day_of_week, ts.slot_index
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
});

module.exports = router;
